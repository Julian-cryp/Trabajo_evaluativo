/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Persistencia;

import Logica.tarea;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Julian
 */
public class ControladorPersistencia {
    
   tareaJpaController Tar = new tareaJpaController();
   
   public List<tarea> traerTarea(){
     return Tar.findTarea_classEntities();
   }
  
   public void Crear(tarea tarea_class){
         Tar.create(tarea_class);
   }
   
   public void Editar(tarea tarea_class){
       try {
           Tar.edit(tarea_class);
       } catch (Exception ex) {
           Logger.getLogger(ControladorPersistencia.class.getName()).log(Level.SEVERE, null, ex);
       }
   }
}
