/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package Logica;

import Controlador.Controller_Tarea;
import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


/**
 *
 * @author Julian
 */
@WebServlet(name = "svTarea", urlPatterns = {"/svTarea"})
public class svTarea extends HttpServlet {

    Controller_Tarea controller = new Controller_Tarea();
    
    
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

    }
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
        
        List<tarea> tareas_clase = new ArrayList<>();
        
        tareas_clase = controller.traerUser();
        
         HttpSession Tareasession = request.getSession();
         Tareasession.setAttribute("tareas_clase", tareas_clase);
        
        response.sendRedirect("Mostrar_tareas.jsp");
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
        
        String Estado = request.getParameter("estado");
         String nombre = request.getParameter("nombre");
        String descripcion = request.getParameter("descripcion");
        String fecha = request.getParameter("fecha");
        String hora = request.getParameter("hora");

        tarea nueva_tarea = new tarea();

        nueva_tarea.setNombre(nombre);
        nueva_tarea.setEstado(Estado);
        nueva_tarea.setDescripcion(descripcion); 
        nueva_tarea.setFecha(fecha);
        nueva_tarea.setHora(hora);
        
        controller.crear(nueva_tarea);
        response.sendRedirect("index.jsp");
  
    }
    
    

    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
