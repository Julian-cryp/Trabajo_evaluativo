/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import Logica.tarea;
import Persistencia.ControladorPersistencia;
import java.util.List;

/**
 *
 * @author Julian
 */

public class Controller_Tarea {
    
    ControladorPersistencia control = new ControladorPersistencia();
    
    public List<tarea> traerUser(){
       return control.traerTarea();
    }
    
    public void crear(tarea tarea_class){
     control.Crear(tarea_class);
    }
}
